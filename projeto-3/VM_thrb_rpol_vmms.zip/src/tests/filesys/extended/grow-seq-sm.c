/* Grows a file from 0 bytes to 5,678 bytes, 1,234 bytes at a
   time. */

#define TEST_SIZE 5678
#include "tests/filesys/extended/grow-seq.inc"
